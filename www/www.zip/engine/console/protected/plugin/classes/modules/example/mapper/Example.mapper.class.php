<?php

class PluginExample_ModuleExample_MapperExample extends Mapper
{

}

?>
