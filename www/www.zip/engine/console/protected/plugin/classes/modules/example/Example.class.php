<?php

class PluginExample_ModuleExample extends Module {


}
?>
