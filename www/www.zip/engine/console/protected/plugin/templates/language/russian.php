<?php
/**
 * Русский языковой файл плагина
 */
return array(
    'name' => 'text',
);

?>
