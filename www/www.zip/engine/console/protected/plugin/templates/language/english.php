<?php
/**
 * English language file for plug-in
 */
return array(
    'name' => 'text',
);

?>
